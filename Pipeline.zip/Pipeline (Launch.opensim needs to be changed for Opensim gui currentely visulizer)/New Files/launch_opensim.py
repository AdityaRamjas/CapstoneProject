import subprocess
from pathlib import Path

OPENSIM_CMD = Path(r"C:\OpenSim 4.6\bin\opensim-cmd.exe")

MODEL = Path(
    r"C:\OpenSim 4.6\sdk\Python\opensim\tests\arm26.osim"
)

if not OPENSIM_CMD.is_file():
    raise FileNotFoundError("OpenSim command-line tool not found.")

if not MODEL.is_file():
    raise FileNotFoundError("OpenSim model not found.")

print("Launching OpenSim 4.6 visualization...")

subprocess.Popen(
    [
        str(OPENSIM_CMD),
        "viz",
        "model",
        str(MODEL)
    ],
    cwd=str(MODEL.parent)
)

print("OpenSim visualization launch requested!")